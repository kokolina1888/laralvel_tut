<?php

namespace Corp;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    //
}
