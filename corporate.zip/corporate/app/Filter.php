<?php

namespace Corp;

use Illuminate\Database\Eloquent\Model;

class Filter extends Model
{
    //
}
