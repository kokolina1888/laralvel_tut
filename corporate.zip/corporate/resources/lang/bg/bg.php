<?php 

return [
'latest_projects' => 'Последни проекти',
'from_blog' => 'От блога',


];