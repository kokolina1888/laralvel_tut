<header>
	<nav class="main-nav">
		<ul>
			<li <?php echo e(Request::is('')?'class = active':''); ?>><a href="<?php echo e(route('blog.index')); ?>">Blog</a></li>
			<li <?php echo e(Request::is('about')?'class = active':''); ?>><a href="<?php echo e(route('about')); ?>">About Me</a></li>
			<li <?php echo e(Request::is('contact')?'class = active':''); ?>><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
			<li <?php echo e(Request::is('contact')?'class = active':''); ?>><a href="<?php echo e(route('admin.login')); ?>">logIn</a></li>
			
		</ul>
	</nav>
</header>