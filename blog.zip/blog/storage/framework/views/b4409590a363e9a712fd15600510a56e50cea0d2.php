<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/css/form.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="container">
	<?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<form action="<?php echo e(route('admin.blog.post_update')); ?>" method="post">
		<div class="input-group">
		<?php if($errors->has('title')): ?>
			<section class="info-box fail">
				<?php echo e($errors->first('title')); ?>				
			</section>
			<?php endif; ?>
			<label for="title">Post Title</label>
			<input type="text" name="title" id="title" <?php echo e($errors->has('title')?'class=has-errors':''); ?> value="<?php echo e(Request::old('title')?Request::old('title'):isset($post)?$post->title:''); ?>">
		</div>
		<div class="input-group">
			<label for="author">Post Author</label>
			<input type="text" name="author" id="author" <?php echo e($errors->has('author')?'class=has-errors':''); ?> value="<?php echo e(Request::old('author')?Request::old('author'):isset($post)?$post->author:''); ?>">
		</div>
		<div class="input-group">
			<label for="category_select">Category</label>
			<select name="category_select" id="category_select">
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
		</div>
		<button type="button" class="btn">Add Category</button>

		<div class="added_categories">
			<ul>
				<?php $__currentLoopData = $post_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

				<li>
					<a href="#" data-category_id = '<?php echo e($post_category->id); ?>'><?php echo e($post_category->name); ?></a>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</ul>
			<input type="hidden" name="categories" id="categories" value="<?php echo e(implode(',', $post_categories_ids)); ?>">
		</div>
		<div class="input-group">
			<label for="body">Post Content</label>
			<textarea id="body" name="body" <?php echo e($errors->has('body')?'class=has-errors':''); ?> ><?php echo e(Request::old('body')?Request::old('body'):isset($post)?$post->body:''); ?></textarea>
		</div>
		<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
		<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
		<button type="submit" class="btn">Update Post</button>

	</form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
		var token = "<?php echo e(Session::token()); ?>";
	</script>
	<script type="text/javascript" src="<?php echo e(URL::to('js/post.js')); ?>"></script><?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>