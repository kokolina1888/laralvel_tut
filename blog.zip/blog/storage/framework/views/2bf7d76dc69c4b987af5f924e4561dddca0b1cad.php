<h1>We Received Your Message!</h1>
<p>Thank you for your message!</p>
<h3>Info: ...</h3>
<p>Subject: <?php echo e($contact_message->subject); ?></p>
<p>Message: <?php echo e($contact_message->body); ?></p>