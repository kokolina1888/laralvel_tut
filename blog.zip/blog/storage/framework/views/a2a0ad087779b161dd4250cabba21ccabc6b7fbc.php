<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	
<title>Admin area</title>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/css/admin.css')); ?>">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<?php echo $__env->yieldContent('styles'); ?>

</head>

<body>
	<?php echo $__env->make('includes.admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('content'); ?>
	<script type="text/javascript" >
		var baseURL = "<?php echo e(URL::to('/')); ?>";
	</script>
	<?php echo $__env->yieldContent('script'); ?>
</body>
</html>