<?php $__env->startSection('content'); ?>
<div class="container">
<h3>Admin area</h3>
	<section id="post-admin">
		<a href="<?php echo e(route('admin.blog.post_edit', ['post_id'=>$post->id])); ?>">Edit Post </a>|
		<a href="<?php echo e(route('admin.blog.post_delete', ['post_id'=>$post->id])); ?>">Delete Post</a>
	</section>
	<section class="post">
		<h1><?php echo e($post->title); ?></h1>
		<?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<p><?php echo e($category->name); ?></p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<span class="info"><?php echo e($post->author); ?>| <?php echo e($post->created_at->diffForHumans()); ?></span>
		<p><?php echo e($post->body); ?></p>
	</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>