<p>Subject <?php echo e($contact_message->subject); ?></p>
Message: <?php echo e($contact_message->subject); ?>