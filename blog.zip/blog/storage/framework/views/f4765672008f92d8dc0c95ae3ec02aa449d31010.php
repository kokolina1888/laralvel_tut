<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/css/modal.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/css/categories.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/css/comon.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="card">
		<header>
			<nav>
				<ul>
					<li>
						<a href="<?php echo e(route('admin.blog.create_post')); ?>" class="btn">New Post</a>
					</li>
					<li>
						<a href="" class="btn">Show All Posts</a>
					</li>
				</ul>

			</nav>
		</header>
		<section>
			<ul>
				<?php if(count($posts) === 0): ?>
				<!-- if no posts -->
				<li>
					No Posts
				</li>
				<?php else: ?> 
				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<!-- if posts -->
				<li>
					<article>
						<div class="post-info">
							<h3><?php echo e($post->title); ?></h3>
							<span class="info"><?php echo e($post->author); ?>| <?php echo e($post->created_at->diffForHumans()); ?></span>
						</div>
						<div class="edit">
							<nav>
								<ul>
									<li>
										<a href="" >View Post</a>
									</li>
									<li>
										<a href="" >Edit Post</a>
									</li>
									<li>
										<a href="" class="danger">Delete Post</a>
									</li>
								</ul>
							</nav>
						</div>
					</article>
				</li>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				<?php endif; ?>
			</ul>
		</section>		
		<section class="pagination">
	
	<?php if($posts->currentPage()!==1): ?>
	<a href="<?php echo e($posts->previousPageUrl()); ?>">
		<span class="fa fa-caret-left"></span>
	</a>
	<?php endif; ?>
	<?php if($posts->currentPage()!==$posts->lastPage() && $posts->hasPages()): ?>
	<a href="<?php echo e($posts->nextPageUrl()); ?>">
		<span class="fa fa-caret-right"></span>
	</a>
	<?php endif; ?>

	
	</section>
	</div>
	<div class="card">
		<header>
			<nav>
				<ul>
					<li>
						<a href="" class="btn">New Message</a>
					</li>
					<li>
						<a href="" class="btn">Show All Messages</a>
					</li>
				</ul>

			</nav>
		</header>
		<section>
			<ul>
				<!-- if no messages -->
				<li>
					No Messages
				</li>
				<!-- if messages -->
				<li>
					<article data-message = "Body" data-id = "ID">
						<div class="message-info">
							<h3>Message Subject</h3>
							<span class="info">Sender...|Date</span>
						</div>
						<div class="edit">
							<nav>
								<ul>
									<li>
										<a href="" >View Message</a>
									</li>

									<li>
										<a href="" class="danger">Delete Message</a>
									</li>
								</ul>
							</nav>
						</div>
					</article>
				</li>
			</ul>
		</section>
	</div>
</div>
<div class="modal" id="contact-message-info">
	<button class="btn" id="modal-close">close</button>
	
</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
	var token = "<?php echo e(Session::token()); ?>";
</script>
<script type="text/javascript" src="<?php echo e(URL::secure('js/modal.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::secure('js/contact_messages.js')); ?>"></script>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>