<header class="top-nav">
	<nav>
		<ul>
			<li <?php echo e(Request::is('')?'class = active':''); ?>>
				<a href="">DashBoard</a>
			</li>
			<li <?php echo e(Request::is('admin')?'class = active':''); ?>>
				<a href="<?php echo e(route('admin.index')); ?>">Posts</a>
			</li>
			<li <?php echo e(Request::is('admin/blog/categories')?'class = active':''); ?>>
				<a href="<?php echo e(route('admin.blog.categories')); ?>">Categories</a>
			</li>
			<li <?php echo e(Request::is('/admin/contact')?'class = active':''); ?>>
				<a href="<?php echo e(route('admin.contact.index')); ?>">Contact Message</a>
			</li>
			<li>
				<a href="<?php echo e(route('admin.logout')); ?>">LogOut</a>
			</li>
		</ul>
	</nav>
</header>