<?php $__env->startSection('title'); ?>
About me
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<article>
	<h1>My name is ...</h1>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora necessitatibus ullam quod soluta saepe odit error, maxime praesentium sunt! Repudiandae, animi tenetur labore atque officiis, maxime suscipit expedita obcaecati nulla.</p>
</article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>