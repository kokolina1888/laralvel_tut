<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/css/modal.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<section class="list">
		<?php if(count($contact_messages) === 0): ?>
		No messages
		<?php endif; ?>

		<?php $__currentLoopData = $contact_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact_message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<article data-message="<?php echo e($contact_message->body); ?>" data-id="<?php echo e($contact_message->id); ?>" class="contact-message">
			<div class="message-info">
				<h3><?php echo e($contact_message->subject); ?></h3>			
			</div>			
			
			<div class="edit">
			<span class="info">Sender: <?php echo e($contact_message->sender); ?> </span>
				<nav>
					<ul>
						<li><a href="#">Show Message</a></li>
						<li><a href="#" class="danger">Delete</a>
						</li>
					</ul>
				</nav>

			</div>

		</article>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>	
	</section>

	<?php if($contact_messages->lastPage()>1): ?>
	<section class="pagination">
		<?php if($contact_messages->currentPage()!==1): ?>
		<a href="<?php echo e($contact_messages->previousPageUrl()); ?>">
			<span class="fa fa-caret-left"></span>
		</a>
		<?php endif; ?>
		<?php if($contact_messages->currentPage()!==$contact_messages->lastPage() && $contact_messages->hasPages()): ?>
		<a href="<?php echo e($contact_messages->nextPageUrl()); ?>">
			<span class="fa fa-caret-right"></span>
		</a>
		<?php endif; ?>
	</section>
	<?php endif; ?>
</div>
<div class="modal" id="contact-message-info">
<button class="btn" id="modal-close">close</button>
	
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	var token="<?php echo e(Session::token( )); ?>";


</script>
<script type="text/javascript" src="<?php echo e(URL::to('js/modal.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::to('js/contact_messages.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::to('js/categories.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>