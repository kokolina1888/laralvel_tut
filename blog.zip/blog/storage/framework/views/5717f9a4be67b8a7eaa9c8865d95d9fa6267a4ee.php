<?php $__env->startSection('title'); ?>
Blog Index 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main">
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

	<article class="blog-post">
		<h3>
			<?php echo e($post->title); ?>

		</h3>
		<span class="subtitle"><?php echo e($post->author); ?> | <?php echo e($post->created_at->diffForHumans()); ?></span>
		<p> <?php echo e($post->body); ?><a href="<?php echo e(route('blog.single', ['post-id'=>$post->id, 'end'=>'frontend'])); ?>"> Read more ...</a></p>
	</article>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	<section class="pagination">
	
	<?php if($posts->currentPage()!==1): ?>
	<a href="<?php echo e($posts->previousPageUrl()); ?>">
		<span class="fa fa-caret-left"></span>
	</a>
	<?php endif; ?>
	<?php if($posts->currentPage()!==$posts->lastPage() && $posts->hasPages()): ?>
	<a href="<?php echo e($posts->nextPageUrl()); ?>">
		<span class="fa fa-caret-right"></span>
	</a>
	<?php endif; ?>

	
	</section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>