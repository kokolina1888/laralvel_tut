<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/css/form.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="container">
	<?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<form action="<?php echo e(route('admin.blog.post_create')); ?>" method="post">
		<div class="input-group">
		<?php if($errors->has('title')): ?>
			<section class="info-box fail">

				<?php echo e($errors->first('title')); ?>

				
			</section>
			<?php endif; ?>
			<label for="title">Post Title</label>
			<input type="text" name="title" id="title" <?php echo e($errors->has('title')?'class=has-errors':''); ?> value="<?php echo e(Request::old('title')); ?>">
		</div>
		<div class="input-group">
			<label for="author">Post Author</label>
			<input type="text" name="author" id="author" <?php echo e($errors->has('author')?'class=has-errors':''); ?> value="<?php echo e(Request::old('author')); ?>">
		</div>
		<div class="input-group">
			<label for="category_select">Category</label>
			<select name="category_select" id="category_select">
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>

		</div>

		<div class="added_categories">
			<ul></ul>
			<input type="hidden" name="categories" id="categories">
		</div>
		<div class="input-group">
			<label for="body">Post Content</label>
			<textarea id="body" name="body" <?php echo e($errors->has('body')?'class=has-errors':''); ?> value="<?php echo e(Request::old('body')); ?>"></textarea>
		</div>
		<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
		<button type="submit" class="btn">Create Post</button>

	</form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
		var token = "<?php echo e(Session::token()); ?>";
	</script>
	<script type="text/javascript" src="<?php echo e(URL::to('js/post.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>