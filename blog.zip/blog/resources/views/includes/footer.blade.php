<footer class="main-footer">
	<ul>
		<li>
			<a href="{{ route('about') }}">About</a>
		</li>
	</ul>
</footer>