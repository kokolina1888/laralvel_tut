<h1>We Received Your Message!</h1>
<p>Thank you for your message!</p>
<h3>Info: ...</h3>
<p>Subject: {{ $contact_message->subject }}</p>
<p>Message: {{ $contact_message->body }}</p>