<p>Subject {{ $contact_message->subject }}</p>
Message: {{ $contact_message->subject }}