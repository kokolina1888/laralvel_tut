<div>{{ $from}}</div>
<h1>{{ $name }}</h1>
<div>
	{{ $content }}
</div>