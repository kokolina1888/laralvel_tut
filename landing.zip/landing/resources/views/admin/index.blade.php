@extends('layouts.admin')

@section('header')

	@include('admin.header')

@endsection

@section('content')

	@yield('section')

@endsection