<?php $__env->startSection('content'); ?>
<section>

	<div class="inner_wrapper">
		<div class="container">
			<h2><?php echo e($page['name']); ?></h2>
			<div class="inner_section">
				<div class="row">
					<div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right"><?php echo Html::image('assets/img/'.$page->images,'',array('class'=>'img-circle delay-03s animated wow zoomIn')); ?></div>
					<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
						<div class=" delay-01s animated fadeInDown wow animated">
							<?php echo $page->text; ?>

						</div>
						
					</div>
					
				</div>
				
				<?php echo link_to(route('home'),'Back'); ?>

				
			</div>
		</div> 
	</div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.pages.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>