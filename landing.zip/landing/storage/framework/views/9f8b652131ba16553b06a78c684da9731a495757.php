<div><?php echo e($from); ?></div>
<h1><?php echo e($name); ?></h1>
<div>
	<?php echo e($content); ?>

</div>