<?php $__env->startSection('content'); ?>
<div class="wrapper container-fluid">
	<div class="row">

		<div class="col-xs-8 col-xs-offset-2">
			<?php echo e($portfolio->name); ?>

		</div>
	</div>

	<div class="row">
		
		<div class="col-xs-8 col-xs-offset-2">
			<?php echo e($portfolio->filter); ?>

		</div>
	</div>

	
	<div class="col-xs-8 col-xs-offset-2">
		<div class="portfolio_img"> <?php echo e(Html::image('assets/img/'.$portfolio->images,$portfolio->name)); ?> </div>  
	</div>
</div>
<a href="<?php echo e(route('home')); ?>">Back</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.noadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>