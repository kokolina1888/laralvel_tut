<?php $__env->startSection('content'); ?>
<?php if(isset($services) && is_object($services)): ?>
<!--Service-->
<section  id="service">
	<div class="container">
		<h2>Services</h2>
		<div class="service_wrapper">

			<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($k == 0 || $k%3 == 0): ?>
			<div class="row <?php echo e(($k != 0) ? 'borderTop' : ''); ?>">
				<?php endif; ?>
				<div class="col-lg-4 <?php echo e(($k%3 > 0) ? 'borderLeft' : ''); ?> <?php echo e(($k > 2) ? 'mrgTop' : ''); ?>">
					<div class="service_block">
						<div class="service_icon delay-03s animated wow  zoomIn"> <span><i class="fa <?php echo e($service->icon); ?>"></i></span> </div>
						<h3 class="animated fadeInUp wow"><a href="<?php echo e(route('service.show', $service->id)); ?>"><?php echo e($service->name); ?></a></h3>
						<p class="animated fadeInDown wow"><?php echo e($service->text); ?></p>
					</div>
				</div>

				<?php if(($k + 1)%3 == 0): ?>
			</div>
			<?php endif; ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     

		</div>
	</div>          
</section>
<!--Service-->
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.noadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>