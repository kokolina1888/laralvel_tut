<?php $__env->startSection('content'); ?>

<?php if(Session::has('status')): ?>
<div class="alert alert-success">
	<button class="close" type="button" data-dismiss="alert">&times;</button>
	<strong>
		<i class="fa fa-check-circle fa-lg fa-fw"></i>Success. &nbsp;
	</strong>
	<?php echo e(Session::get('status')); ?>

</div>
<?php endif; ?>
<div style="margin: 0 50 0 50">
	<?php if($peoples): ?>
	<table class="table table-hover">
		<thead>
			<th>No</th>
			<th>Name</th>
			<th>Position</th>
			<th>Image</th>
			<th>Text</th>
			<th>Created At</th>
			<th>Updated At</th>
			<th>Delete</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $peoples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$people): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($k+1); ?></td>
				<td><?php echo Html::link(route('team.edit', ['people'=>$people->id]), $people->name, ['alt'=>$people->name]); ?>

				</td>
				<td><?php echo e($people->position); ?></td>
				<td>
					<?php echo Html::image('assets/user_img/'.$people['images'],'',['class'=>'img-circle img-responsive','width'=>'150px']); ?>

				</td>
				<td><?php echo e($people->text); ?></td>
				<td>
					<?php if($people->created_at): ?>
					<?php echo e($people->created_at->diffForHumans()); ?>

					<?php endif; ?>
				</td>

				<td>
					<?php if($people->updated_at): ?>
					<?php echo e($people->updated_at->diffForHumans()); ?>

					<?php endif; ?>
				</td>
				<td>
					<?php echo Form::open(['url'=>route('team.destroy',['people'=>$people->id]), 'class'=>'form-horizontal','method' => 'POST']); ?>

					<?php echo e(method_field('DELETE')); ?>					
					<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>

					<?php echo Form::close(); ?>

				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php endif; ?>
	<?php echo Html::link(route('team.create'), "New Team Member"); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>