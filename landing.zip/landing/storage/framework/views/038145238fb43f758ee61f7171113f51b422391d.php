<div class="wrapper container-fluid">
<?php if(count($errors)>0): ?>
            <div class="alert alert-danger">

              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
<?php echo Form::open(['url' => route('pagesEdit',array('page'=>$data['id'])),'class'=>'form-horizontal','method'=>'POST','enctype'=>'multipart/form-data']); ?>

    <div class="form-group">
    	<?php echo Form::hidden('id', $data['id']); ?>

	     <?php echo Form::label('name', 'Name:',['class'=>'col-xs-2 control-label']); ?>

	     <div class="col-xs-8">
		 	<?php echo Form::text('name', $data['name'], ['class' => 'form-control','placeholder'=>'Enter page name']); ?>

		 </div>
    </div>
    
    <div class="form-group">
	     <?php echo Form::label('alias', 'Alias:',['class'=>'col-xs-2 control-label']); ?>

	     <div class="col-xs-8">
		 	<?php echo Form::text('alias', $data['alias'], ['class' => 'form-control','placeholder'=>'Enter page alias']); ?>

		 </div>
    </div>
    
    <div class="form-group">
	     <?php echo Form::label('text', 'Text:',['class'=>'col-xs-2 control-label']); ?>

	     <div class="col-xs-8">
		 	<?php echo Form::textarea('text', $data['text'], ['id'=>'editor','class' => 'form-control','placeholder'=>'Enter page text']); ?>

		 </div>
    </div>
    
    <div class="form-group">
    	<?php echo Form::label('old_images', 'Image:',['class'=>'col-xs-2 control-label']); ?>

    	<div class="col-xs-offset-2 col-xs-10">
			<?php echo Html::image('assets/img/'.$data['images'],'',['class'=>'img-circle img-responsive','width'=>'150px']); ?>

			<?php echo Form::hidden('old_images', $data['images']); ?>

    	</div>
    </div>
    
    <div class="form-group">
	     <?php echo Form::label('images', 'Image:',['class'=>'col-xs-2 control-label']); ?>

	     <div class="col-xs-8">
		 	<?php echo Form::file('images', ['class' => 'filestyle','data-buttonText'=>'Choose image','data-buttonName'=>"btn-primary",'data-placeholder'=>"No file selected"]); ?>

		 </div>
    </div>
    

    
      <div class="form-group">
	    <div class="col-xs-offset-2 col-xs-10">
	      <?php echo Form::button('Save', ['class' => 'btn btn-primary','type'=>'submit']); ?>

	    </div>
	  </div>
    
<?php echo Form::close(); ?>


 <script>
	CKEDITOR.replace( 'editor' );
</script>
</div>