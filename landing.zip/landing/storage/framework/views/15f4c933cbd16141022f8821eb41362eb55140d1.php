<?php $__env->startSection('content'); ?>

<!-- PORTFOLIO -->
  <?php if(isset($portfolios) && is_object($portfolios)): ?>

 
  <section id="Portfolio" class="content"> 

    <!-- Container -->
    <div class="container portfolio_title"> 

      <!-- Title -->
      <div class="section-title">
        <h2>Portfolio</h2>
      </div>
      <!--/Title --> 

    </div>
    <!-- Container -->

    <div class="portfolio-top"></div>

    <!-- Portfolio Filters -->
    <div class="portfolio"> 

      <?php if(isset($tags)): ?>
      <div id="filters" class="sixteen columns">
        <ul class="clearfix">
          <li><a id="all" href="#" data-filter="*" class="active">
            <h5>All</h5></a></li>

            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a class="" href="#" data-filter=".<?php echo e($tag); ?>">
              <h5><?php echo e($tag); ?></h5>
            </a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <!--/Portfolio Filters --> 
        <?php endif; ?>


        <!-- Portfolio Wrapper -->
        <div class="isotope fadeInLeft animated wow" style="position: relative; overflow: hidden; height: 480px;" id="portfolio_wrapper"> 

          <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <!-- Portfolio Item -->
          <div style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1); width: 337px; opacity: 1;" class="portfolio-item one-four   <?php echo e($item->filter->name); ?> isotope-item">
            <div class="portfolio_img"> <?php echo e(Html::image('assets/user_img/'.$item->images,$item->name)); ?> </div>        
            <div class="item_overlay">
              <div class="item_info"> 
                <h4 class="project_name"><a href="<?php echo e(route('portfolio.show', $item->id)); ?>"><?php echo e($item->name); ?></a></h4>
              </div>
            </div>
          </div>
          <!--/Portfolio Item --> 


          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <!--/Portfolio Wrapper --> 

      </div>
      <!--/Portfolio Filters -->

      <div class="portfolio_btm"></div>


      <div id="project_container">
        <div class="clear"></div>
        <div id="project_data"></div>
      </div>


    </section>
    <!--/Portfolio --> 


    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.noadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>