<?php $__env->startSection('content'); ?>

<?php if(Session::has('status')): ?>
<div class="alert alert-success">
	<button class="close" type="button" data-dismiss="alert">&times;</button>
	<strong>
		<i class="fa fa-check-circle fa-lg fa-fw"></i>Success. &nbsp;
	</strong>
	<?php echo e(Session::get('status')); ?>

</div>
<?php endif; ?>
<div style="margin: 50px">
	<?php if($users): ?>
	<table class="table table-hover">
		<thead>
			<th>No</th>
			<th>email</th>
			<th>role</th>
			<th>Created At</th>
			<th>Updated At</th>
			<th>Delete</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($k+1); ?></td>
				<td><?php echo Html::link(route('users.edit', ['id'=>$user->id]), $user->email, ['alt'=>$user->email]); ?>

				</td>

				<td>
					<?php echo e($user->role); ?>

				</td>
				<td>
					<?php echo e($user->created_at->diffForHumans()); ?>

				</td>
				<td>
					<?php if($user->updated_at): ?>
					<?php echo e($user->created_at->diffForHumans()); ?>

					<?php endif; ?>
				</td>				
				<td>
					<?php echo Form::open(['url'=>route('users.destroy',['id'=>$user->id]), 'class'=>'form-horizontal','method' => 'POST']); ?>

					<?php echo e(method_field('DELETE')); ?>


					
					<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>


					<?php echo Form::close(); ?>


				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php endif; ?>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>