<?php $__env->startSection('content'); ?>
<div class="wrapper container-fluid">
	<?php if(count($errors)>0): ?>
	<div class="alert alert-danger">

		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>
	<?php echo Form::model($user, ['method'=>'PATCH', 'class'=>'form-horizontal', 'action' => ['UsersController@update', $user->id]]); ?>	
	
	<div class="form-group">
    	<?php echo Form::hidden('id', $user->id); ?>

		
		<?php echo Form::label('email','Email',['class' => 'col-xs-2 control-label']); ?>

		<div class="col-xs-8">
			<?php echo Form::text('email', $user->email,['class' => 'form-control']); ?>

		</div>

	</div>

	<div class="form-group">
    	
		<?php echo Form::label('role','Role',['class' => 'col-xs-2 control-label']); ?>

		<div class="col-xs-8">
			<?php echo Form::select('role', $roles, $user->role, ['class' => 'form-control']); ?>

		</div>

	</div>

	
	


	<div class="form-group">
		<div class="col-xs-offset-2 col-xs-10">
			<?php echo Form::button('Update', ['class' => 'btn btn-primary','type'=>'submit']); ?>

		</div>
	</div>
	
	
	
	<?php echo Form::close(); ?>

	
	<script>
		CKEDITOR.replace('editor');
	</script>
	
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>