<?php $__env->startSection('content'); ?>
 <?php if(isset($peoples) && is_object($peoples)): ?>


    <section class="page_section team" id="team"><!--main-section team-start-->
      <div class="container">
        <h2>Team</h2>
        <h6>Lorem ipsum dolor sit amet, consectetur adipiscing.</h6>
        <div class="team_section clearfix">
          <?php $__currentLoopData = $peoples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$people): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="team_area">
            <div class="team_box wow fadeInDown delay-03s">
              <div class="team_box_shadow"><a href="javascript:void(0)"></a></div>
             <a href="<?php echo e(route('team.show', $people->id)); ?>"><?php echo Html::image('/assets/img/'. $people->images, $people->name); ?></a> 
              <ul>
                <li><a href="javascript:void(0)" class="fa fa-twitter"></a></li>
                <li><a href="javascript:void(0)" class="fa fa-facebook"></a></li>
                <li><a href="javascript:void(0)" class="fa fa-pinterest"></a></li>
                <li><a href="javascript:void(0)" class="fa fa-google-plus"></a></li>
              </ul>
            </div>
            <h3 class="wow fadeInDown delay-0<?php echo e($k*3+3); ?>s"><?php echo e($people->name); ?></h3>
            <span class="wow fadeInDown delay-0<?php echo e($k*3+3); ?>s"><?php echo e($people->position); ?></span>
            <p class="wow fadeInDown delay-0<?php echo e($k*3+3); ?>s">
              <?php echo e($people->text); ?>

            </p>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
    <?php endif; ?>
    <!--/Team-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.noadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>