<?php if(Session::has('status')): ?>
<div class="alert alert-success">
	<button class="close" type="button" data-dismiss="alert">&times;</button>
	<strong>
		<i class="fa fa-check-circle fa-lg fa-fw"></i>Success. &nbsp;
	</strong>
	<?php echo e(Session::get('status')); ?>

</div>
<?php endif; ?>
<div style="margin: 0 50 0 50">
	<?php if($pages): ?>
	<table class="table table-hover">
		<thead>
			<th>No</th>
			<th>Name</th>
			<th>Alias</th>
			<th>Text</th>
			<th>Created At</th>
			<th>Updated At</th>
			<th>Delete</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($k+1); ?></td>
				<td><?php echo Html::link(route('pagesEdit', ['page'=>$page->id]), $page->name, ['alt'=>$page->name]); ?>

				</td>
				<td><?php echo e($page->alias); ?></td>
				<td><?php echo e($page->text); ?></td>
				<td><?php echo e($page->created_at->diffForHumans()); ?></td>
				<td>
					<?php if($page->updated_at): ?>
					<?php echo e($page->updated_at->diffForHumans()); ?>

					<?php endif; ?>
				</td>
				<td>
					<?php echo Form::open(['url'=>route('pagesEdit',['page'=>$page->id]), 'class'=>'form-horizontal','method' => 'POST']); ?>

					<?php echo e(method_field('DELETE')); ?>


					
					<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>


					<?php echo Form::close(); ?>


				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php endif; ?>
	<?php echo Html::link(route('pagesAdd'), "New Page"); ?>

</div>