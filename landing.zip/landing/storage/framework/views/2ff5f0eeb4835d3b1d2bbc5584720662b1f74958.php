<?php $__env->startSection('content'); ?>

<?php if(Session::has('status')): ?>
<div class="alert alert-success">
	<button class="close" type="button" data-dismiss="alert">&times;</button>
	<strong>
		<i class="fa fa-check-circle fa-lg fa-fw"></i>Success. &nbsp;
	</strong>
	<?php echo e(Session::get('status')); ?>

</div>
<?php endif; ?>
<div style="margin: 50px">
	<?php if($portfolios): ?>
	<table class="table table-hover">
		<thead>
			<th>No</th>
			<th>Name</th>
			<th>Tag</th>
			<th>Image</th>
			<th>Created At</th>
			<th>Updated At</th>
			<th>Delete</th>
		</thead>
		<!-- Portfolio Item -->

		<tbody>
			<?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($k+1); ?></td>
				<td><?php echo Html::link(route('portfolio.edit', ['id'=>$portfolio->id]), $portfolio->name, ['alt'=>$portfolio->name]); ?>

				</td>
				<td><?php echo e($portfolio->filter->name); ?></td>
				<td>
					<div class="portfolio_img" style="width: 250px"> 
						<?php echo e(Html::image('assets/user_img/'.$portfolio->images, $portfolio->name)); ?> 
					</div>   
				</td>
				<td><?php echo e($portfolio->created_at->diffForHumans()); ?></td>
				<td>
					<?php if($portfolio->updated_at): ?>
					<?php echo e($portfolio->updated_at->diffForHumans()); ?>

					<?php endif; ?>
				</td>
				<td>
					<?php echo Form::open(['url'=>route('portfolio.destroy',['id'=>$portfolio->id]), 'class'=>'form-horizontal','method' => 'POST']); ?>

					<?php echo e(method_field('DELETE')); ?>



					<?php echo Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit']); ?>


					<?php echo Form::close(); ?>


				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<?php endif; ?>
	<?php echo Html::link(route('portfolio.create'), "New Portfolio", ['class'=>'btn btn-info']); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>