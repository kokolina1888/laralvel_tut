<?php if(isset($messages) && count($messages) >0): ?>
<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($message); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($pages) && is_object($pages)): ?>
<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($k%2 == 0): ?>
<section id="<?php echo e($page->alias); ?>" class="top_cont_outer">
  <div class="hero_wrapper">
    <div class="container">
      <div class="hero_section">
        <div class="row">
          <div class="col-lg-5 col-sm-7">
            <div class="top_left_cont zoomIn wow animated"> 

              <?php echo $page->text; ?>

              <a href="<?php echo e(route('page',array('alias'=>$page->alias))); ?>" class="read_more2">Read more</a> </div>
            </div>
            <div class="col-lg-7 col-sm-5">
              <?php echo Html::image('assets/img/'.$page->images); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php else: ?> 
  <section id="<?php echo e($page->alias); ?>"><!--Aboutus-->
    <div class="inner_wrapper">
      <div class="container">
        <h2><?php echo e($page->name); ?></h2>
        <div class="inner_section">
          <div class="row">
            <div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
              <?php echo Html::image('assets/img/'.$page->images,'',array('class'=>'img-circle delay-03s animated wow zoomIn')); ?>

            </div>
            <div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
              <div class=" delay-01s animated fadeInDown wow animated">
                <?php echo $page->text; ?>

              </div>
              <div class="work_bottom"> <span>Want to know more..</span> <a href="<?php echo e(route('page',array('alias'=>$page->alias))); ?>" class="contact_btn">Contact Us</a> </div>       
            </div>

          </div>


        </div>
      </div> 
    </div>
  </section>

  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  <?php if(isset($services) && is_object($services)): ?>
  <!--Service-->
  <section  id="service">
    <div class="container">
      <h2>Services</h2>
      <div class="service_wrapper">

        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($k == 0 || $k%3 == 0): ?>
        <div class="row <?php echo e(($k != 0) ? 'borderTop' : ''); ?>">
          <?php endif; ?>
          <div class="col-lg-4 <?php echo e(($k%3 > 0) ? 'borderLeft' : ''); ?> <?php echo e(($k > 2) ? 'mrgTop' : ''); ?>">
            <div class="service_block">
              <div class="service_icon delay-03s animated wow  zoomIn"> <span><i class="fa <?php echo e($service->icon); ?>"></i></span> </div>
              <h3 class="animated fadeInUp wow"><?php echo e($service->name); ?></h3>
              <p class="animated fadeInDown wow"><?php echo e($service->text); ?></p>
            </div>
          </div>
          
          <?php if(($k + 1)%3 == 0): ?>
        </div>
        <?php endif; ?>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     

      </div>
    </div>          
  </section>
  <!--Service-->
  <?php endif; ?>

 <!-- PORTFOLIO -->
  <?php if(isset($portfolios) && is_object($portfolios)): ?>

 
  <section id="Portfolio" class="content"> 

    <!-- Container -->
    <div class="container portfolio_title"> 

      <!-- Title -->
      <div class="section-title">
        <h2>Portfolio</h2>
      </div>
      <!--/Title --> 

    </div>
    <!-- Container -->

    <div class="portfolio-top"></div>

    <!-- Portfolio Filters -->
    <div class="portfolio"> 


      <?php if(isset($tags)): ?>
      <div id="filters" class="sixteen columns">
        <ul class="clearfix">
          <li><a id="all" href="#" data-filter="*" class="active">
            <h5>All</h5></a></li>

            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a class="" href="#" data-filter=".<?php echo e($tag); ?>">
              <h5><?php echo e($tag); ?></h5>
            </a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <!--/Portfolio Filters --> 
        <?php endif; ?>


        <!-- Portfolio Wrapper -->
        <div class="isotope fadeInLeft animated wow" style="position: relative; overflow: hidden; height: 480px;" id="portfolio_wrapper"> 

          <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <!-- Portfolio Item -->
          <div style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1); width: 337px; opacity: 1;" class="portfolio-item one-four   <?php echo e($item->filter); ?> isotope-item">
            <div class="portfolio_img"> <?php echo e(Html::image('assets/img/'.$item->images,$item->name)); ?> </div>        
            <div class="item_overlay">
              <div class="item_info"> 
                <h4 class="project_name"><a href="<?php echo e(route('portfolio', $item->id)); ?>"><?php echo e($item->name); ?></a></h4>
              </div>
            </div>
          </div>
          <!--/Portfolio Item --> 


          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <!--/Portfolio Wrapper --> 

      </div>
      <!--/Portfolio Filters -->

      <div class="portfolio_btm"></div>


      <div id="project_container">
        <div class="clear"></div>
        <div id="project_data"></div>
      </div>


    </section>
    <!--/Portfolio --> 


    <?php endif; ?>
    <?php if(isset($peoples) && is_object($peoples)): ?>


    <section class="page_section team" id="team"><!--main-section team-start-->
      <div class="container">
        <h2>Team</h2>
        <h6>Lorem ipsum dolor sit amet, consectetur adipiscing.</h6>
        <div class="team_section clearfix">
          <?php $__currentLoopData = $peoples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$people): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="team_area">
            <div class="team_box wow fadeInDown delay-03s">
              <div class="team_box_shadow"><a href="javascript:void(0)"></a></div>
              <?php echo Html::image('/assets/img/'. $people->images, $people->name); ?>

              <ul>
                <li><a href="javascript:void(0)" class="fa fa-twitter"></a></li>
                <li><a href="javascript:void(0)" class="fa fa-facebook"></a></li>
                <li><a href="javascript:void(0)" class="fa fa-pinterest"></a></li>
                <li><a href="javascript:void(0)" class="fa fa-google-plus"></a></li>
              </ul>
            </div>
            <h3 class="wow fadeInDown delay-0<?php echo e($k*3+3); ?>s"><?php echo e($people->name); ?></h3>
            <span class="wow fadeInDown delay-0<?php echo e($k*3+3); ?>s"><?php echo e($people->position); ?></span>
            <p class="wow fadeInDown delay-0<?php echo e($k*3+3); ?>s">
              <?php echo e($people->text); ?>

            </p>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
    <?php endif; ?>
    <!--/Team-->
    <!--Footer-->
    <footer class="footer_wrapper" id="contact">
      <div class="container">
        <section class="page_section contact" id="contact">
          <div class="contact_section">
            <h2>Contact Us</h2>
            <div class="row">
              <div class="col-lg-4">

              </div>
              <div class="col-lg-4">

              </div>
              <div class="col-lg-4">

              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-4 wow fadeInLeft">	
             <div class="contact_info">
              <div class="detail">
                <h4>UNIQUE Infoway</h4>
                <p>104, Some street, NewYork, USA</p>
              </div>
              <div class="detail">
                <h4>call us</h4>
                <p>+1 234 567890</p>
              </div>
              <div class="detail">
                <h4>Email us</h4>
                <p>support@sitename.com</p>
              </div> 
            </div>



            <ul class="social_links">
              <li class="twitter animated bounceIn wow delay-02s"><a href="javascript:void(0)"><i class="fa fa-twitter"></i></a></li>
              <li class="facebook animated bounceIn wow delay-03s"><a href="javascript:void(0)"><i class="fa fa-facebook"></i></a></li>
              <li class="pinterest animated bounceIn wow delay-04s"><a href="javascript:void(0)"><i class="fa fa-pinterest"></i></a></li>
              <li class="gplus animated bounceIn wow delay-05s"><a href="javascript:void(0)"><i class="fa fa-google-plus"></i></a></li> 
            </ul>
          </div>
          <div class="col-lg-8 wow fadeInLeft delay-06s">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <button class="close" type="button" data-dismiss="alert">&times;</button>
              <strong>
                <i class="fa fa-check-circle fa-lg fa-fw"></i>Success. &nbsp;
              </strong>
              <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(count($errors)>0): ?>
            <div class="alert alert-danger">

              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
            <div class="form">
              <form action="<?php echo e(route('send_mail')); ?>" method="post">
                <?php echo e(csrf_field()); ?>


                <input class="input-text" type="text" name="name" placeholder="Your Name *" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">
                <input class="input-text" type="text" name="email" placeholder="Your E-mail *" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">
                <textarea class="input-text text-area" name="text" cols="0" rows="0" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" placeholder="Your Message *"></textarea>
                <input class="input-btn" type="submit" value="send message">
              </form>
            </div>
          </div>
        </div>
      </section>