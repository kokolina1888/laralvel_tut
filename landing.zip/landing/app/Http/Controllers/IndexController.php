<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Page;
use App\Service;
use App\Portfolio;
use App\People;

use App\Http\Requests\ContactUserRequest;
use App\Mail\UserContactMessage;
use Mail;

use DB;


class IndexController extends Controller
{
    //

	public function execute(Request $request) {

		

		$pages = Page::all();
		$portfolios = Portfolio::get(array('id','name','filter','images'));
		$services = Service::where('id','<',20)->get();
		$peoples = People::take(3)->get();

		$tags = DB::table('portfolios')->distinct()->pluck('filter');


		$menu = array();
		foreach($pages as $page) {
			$item = array('title' =>$page->name,'alias'=>$page->alias);
			array_push($menu,$item);
		}
		
		$item = array('title'=>'Services','alias'=>'service');
		array_push($menu,$item);
		
		$item = array('title'=>'Portfolio','alias'=>'Portfolio');
		array_push($menu,$item);
		
		$item = array('title'=>'Team','alias'=>'team');
		array_push($menu,$item);
		
		$item = array('title'=>'Contact','alias'=>'contact');
		array_push($menu,$item);
		
		return view('site.index',array(

			'menu'=> $menu,
			'pages' => $pages,
			'services' => $services,
			'portfolios' => $portfolios,
			'peoples' => $peoples,
			'tags'=>$tags



			));
	}

	public function sendMail(ContactUserRequest $request){
		
			$data = $request->all();

			
			$admin ='kokolina18@abv.bg'; 

			Mail::to($admin)->send(new UserContactMessage($data));		
			
			
			return back()->withSuccess('Thank you for your message. It has been send.');
			//mail

		}
	}

